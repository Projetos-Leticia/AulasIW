<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>JavaScript</title>
<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body>
<div>
<h1 style="border: 2px solid"> </h1>
<p></p>
<h2 style="border: 2px solid"></h2>
<p></p>
<p></p>
<p></p>
<p></p>
<p><font size=“12” color=“blue”></font></p>
<p></p>

 <h2 style="border: 2px solid"> </h2>

 <p></p>
<p></p>
<p></p>

 <p><a href="index.html"> Clique Aqui</a> para voltar a Tela Inicial</p>

 </div>
<footer>
<p>Rodapé</p>
</footer>

</body>
</html>